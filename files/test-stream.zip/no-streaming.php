
    <header>
        <div class="header-content">
            <div class="header-content-inner">
                <h1>Op dit moment is er geen live evenement</h1>
                <hr>
            </div>
        </div>
    </header>
    <section class="bg-primary" id="about">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-lg-offset-2 text-center">
                    <h2 class="section-heading">Hieronder staan een aantal afspeel-lijsten</h2>
                    <hr class="light">
                </div>
            </div>
        </div>
    </section>
<aside class="bg-dark">
        <div class="container text-center">
            <div class="call-to-action">
<div class="g-ytsubscribe" data-channel="NaturalisLeiden" data-layout="full" data-theme="dark" data-count="default"></div><br>
            </div>
        </div>
    </aside>


    <section class="no-padding" id="portfolio">
        <div class="container-fluid">
            <div class="row no-gutter">
                <div class="col-lg-4 col-sm-6">
                    <a href="#" class="portfolio-box">
                      <iframe width="650" height="320" src="https://www.youtube.com/embed/MkvioZe36PU?list=PLwgtqLxw0wAhFFXEckAkqky66CjYqQupC&amp;controls=0" frameborder="0" allowfullscreen></iframe> 
<div class="portfolio-box-caption">
                            <div class="portfolio-box-caption-content">
                                <div class="project-category text-faded">
                                    Afspeellijst
                                </div>
                                <div class="project-name">
                                    Superzintuigen
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-4 col-sm-6">
                    <div class="portfolio-box">
<iframe width="650" height="320" src="https://www.youtube.com/embed/RvgauQ7MsAI?list=PLwgtqLxw0wAh59L3rH9AO7Ue4CY8A-njI&amp;controls=0" frameborder="0" allowfullscreen></iframe>
<div class="portfolio-box-caption">
                            <div class="portfolio-box-caption-content">
                                <div class="project-category text-faded">
                                    Afspeellijst
                                </div>
                                <div class="project-name">
                                    Tientje voor T.rex
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-6">
                    <a class="portfolio-box">
                       <iframe width="650" height="320" src="https://www.youtube.com/embed/_iI2JeG8n8Y?list=PLwgtqLxw0wAjQOwrD4HQVZejO0T6s4r4Y&amp;controls=0" frameborder="0" allowfullscreen></iframe> 
<div class="portfolio-box-caption">
                            <div class="portfolio-box-caption-content">
                                <div class="project-category text-faded">
                                    Afspeellijst
                                </div>
                                <div class="project-name">
                                    Hidden Treasures
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </section>

