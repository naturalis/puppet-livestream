
    <header>
        <div class="header-content">
            <div class="header-content-inner">
                <h1>We zijn live !</h1>
                <hr>
            </div>
        </div>
    </header>
    <section class="bg-primary" id="about">
        <div class="container">
            <div class="row">
                <div class="text-center">
                    <h2 class="section-heading">

<?php           

echo <<<EOT
{$YouTubeLive->live_video_title}<br>
EOT;
?>  
</h2>
                  <hr class="light">
<?php

echo <<<EOT
 {$YouTubeLive->live_video_description}<br>
<br>
EOT;
	 $YouTubeLive->setEmbedSizeByWidth(1024);
	// $YouTubeLive->setEmbedSizeByHeight(600);
	 $YouTubeLive->embed_autoplay = true;
	echo $YouTubeLive->embedCode();

?>                
</div>
            </div>
        </div>
    </section>
<aside class="bg-dark">
        <div class="container text-center">
            <div class="call-to-action">
<div class="g-ytsubscribe" data-channel="NaturalisLeiden" data-layout="full" data-theme="dark" data-count="default"></div><br>
            </div>
        </div>
    </aside>

